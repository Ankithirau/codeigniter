<?php

class from_control extends CI_Controller
{	
	 public function index() 
	{
		$this->load->view('newv');
	}
	public function getdt(){
		// $this->load->
		// $this->load->database();
		if (isset($_REQUEST['btn'])) {
		 $data['name']= $this->input->post('nam');
		 $data['email']= $this->input->post('em');
		 $data['password']= $this->input->post('pass');
		 $data['mobile']= $this->input->post('mob');
		 $data['city']= $this->input->post('city');
		// $data['record'] = array('name' =>$nam,'email' =>$em,'password' =>$pass,'mobile' =>$mob,'city'=>$city);
		$this->firstdm->randomdt($data);			
		}
		
		// $this->load->view('data_view',$data);
	}
}
?>