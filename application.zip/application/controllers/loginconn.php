<?php
class loginconn extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('loginmodel');
	}
	function index(){
		$this->load->view('loginview');
	}
	function newlogin(){
		$this->form_validation->set_rules('user','username','required');
		$this->form_validation->set_rules('pass','password','required');
		if ($this->form_validation->run()==false) {
			$this->load->view('loginview');
		}
		else{
			$name=$this->input->post('user');
			$pass=$this->input->post('pass');
			if ($this->loginmodel->nlogin($name,$pass)>0){
				echo "login successfully";
			}
			else{
				echo"error in login";
			}
		}
	}
}
?>