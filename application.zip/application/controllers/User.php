<?php

class User extends CI_controller
{
	function __construct()
{
    parent:: __construct();
   	$this->load->model('User_model');
}

	function create(){
		$this->load->helper('text');
		$string="this is something to be change";
		$native['string']=$string;
		
		$this->form_validation->set_rules('name','Name','required');
		$this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('mobile','Mobile','required');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('city','City','required');
			$dtarray=array(
			'name'=>$this->input->post('name'),
			'email'=>$this->input->post('email'),
			'mobile'=>$this->input->post('mobile'),
			'password'=>$this->input->post('password'),
			'city'=>$this->input->post('city'));
			$this->User_model->create($dtarray);
			// $this->session->set_flashdata('success','record save successfully');
			// redirect(base_url().'user/index');
			$this->load->view('create',$native);
		
		
	}	

}

?>