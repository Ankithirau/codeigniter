<?php
class eng extends CI_Controller
{
	public function index(){
		$date['index']="index page";
		$this->load->view('demo',$date);
	}
	public function about(){
		$date['about']="About page";
		$this->load->view('about',$date);
	}
	public function home(){
		$date['Home']="Home page";
		$this->load->view('home',$date);
	}
}
?>