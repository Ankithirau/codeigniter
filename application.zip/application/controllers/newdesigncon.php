<?php

class newdesigncon extends CI_Controller
{
	function __construct()
  {
          parent::__construct();
         $this->load->helper('denim_helper');

  }
	function index(){
		msg();//call helper
		// $this->load->view('crview');
		// $this->load->helper('');
	}
}

?>