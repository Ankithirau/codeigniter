<?php
class prime extends CI_Controller
{
	public function index()
	{
		$this->load->view('View_prime');
	}
	public function usedt(){
		if (isset($_REQUEST['btn'])) {
			$n=$_POST['n'];
			//$res="";
			for ($i=2; $i<$n ; $i++) { 
				if ($n%$i==0) {
					$res=true;
					break;
				}
			}
			if (isset($res) && $res) {
				echo "not prime";
			}
			else{
				echo"prime";
			}
		}
		 $this->load->view('View_prime');	
	} 
}

?>