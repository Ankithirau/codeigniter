<?php
class myprac extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->model('era_demo');
	}
	function index(){
		$this->load->view('newcreative_idea');
	}
	function newdt(){
		$data['name'] =$this->input->post('name');
		$this->era_demo->unique_demo($data);
	}

}
?>