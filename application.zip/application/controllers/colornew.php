<?php
class colornew extends CI_Controller
{
	
	function index()
	{
		$this->load->view('fac');//show view
	}
	function getdt(){

		if ($this->input->post('blue')) { 
		// check value is set or not
			$data['blue']=$this->input->post('blue');
			//assign value to data value	
		}
		elseif ($this->input->post('red')) {
			$data['red']=$this->input->post('red');	
		}
		elseif ($this->input->post('green')) {
			$data['green']=$this->input->post('green');	
		}
			$this->load->view('fac',$data);
	}
}
?>