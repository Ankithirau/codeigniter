<?php
class Newweb extends CI_Controller
{
	public function index(){
		$this->load->view('header');
		$this->load->view('newhome');
		$this->load->view('footer');
	}
	public function Aboutus(){
		$this->load->view('header');
		$this->load->view('aboutus');
		$this->load->view('footer');
	}
	public function services(){
		$this->load->view('header');
		$this->load->view('services');
		$this->load->view('footer');
	}
	public function Contactus(){
		$this->load->view('header');
		$this->load->view('Contactus');
		$this->load->view('footer');
	}
}
?>