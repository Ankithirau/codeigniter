<?php
class Newmargin extends CI_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('My_Model');
	}
		public function newdt()
		{
		$this->load->view('newv');	
		if($this->input->post('btn')) {
		 $data['name']= $this->input->post('nam');
		 $data['email']= $this->input->post('em');
		 $data['password']= $this->input->post('pass');
		 $data['mobile']= $this->input->post('mob');
		 $data['city']= $this->input->post('city');
		// $data['record'] = array('name' =>$nam,'email' =>$em,'password' =>$pass,'mobile' =>$mob,'city'=>$city);
		$this->My_Model->home($data);			
		}
		
	}
}
?>