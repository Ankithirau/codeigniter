<?php
class demo_model extends CI_Controller
{
	public function index()// deafault method which is autorun
	{	$this->load->helper('url');//load helper
		$this->load->model('My_model');//manual load model
		$date['about']="About page";
		//store value any variable $data
		$this->My_model->demo($data);//send value to medel
		$this->load->view('tree',$data);//send data to view tree
	}
}
?>