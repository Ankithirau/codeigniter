<?php
class facto extends CI_Controller
{
	public function index(){
		$this->load->model('My_model');
		$data['getdt']= $this->My_model->mydemo();
		$this->load->view('fac',$data);
	}
	// public function facdt(){
	// 	$p=$this->input->post('n');
	// 	$s=1;
	// 	for($i=$p;$i>1;$i--) { 
	// 		$s=$s*$i;
	// 	}
	// 	$this->load->view('view_fac',array('result'=>$s));
	// }
}

?>