<?php 
class newdemo extends CI_Controller
{
	public function __construct(){
		parent::__construct();// load parent constructor
		$this->load->model('My_newmodel');	//load model
	}
	public function res(){ // registrations functons
		
		$this->load->view('intell'); //load view
		$this->form_validation->set_rules('name','Name','required');
		$this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('mobile','Mobile','required');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('city','City','required');
		$data['name']=$this->input->post('name'); //taking input from view
		$data['email']=$this->input->post('email');
		$data['password']=$this->input->post('password');
		$data['mobile']=$this->input->post('mobile');
		$data['city']=$this->input->post('city');
		$this->My_newmodel->msg($data);// send registration data to model
		redirect("newdemo/displaydata");//redirect to display page
	}
	public function new_update_skill(){
		$this->load->view('new_update');//load view
	}
	public function displaydata()
	{
		$result['menu']=$this->My_newmodel->fetch_data();// taking data from model and store data in variable
		$this->load->view('intell',$result);//load view		
	}
	public function updatedata(){
			$id=$this->input->get('id');//taking id from view update/delete button 
			$demo['win']=$this->My_newmodel->update_newdata($id);//send id to model and store data in variable
			$this->load->view('prac',$demo);//send $demo to view to fetch data by foreachloop
			// $data['name']=$this->input->post('name');
			// $data['email']=$this->input->post('email');
			// $data['password']=$this->input->post('password');
			// $data['mobile']=$this->input->post('mobile');
			// $data['city']=$this->input->post('city');
				// $name=$this->input->post('name');
				// $email=$this->input->post('email');
				// $password=$this->input->post('password');
				// $mobile=$this->input->post('mobile');
				// $city=$this->input->post('city');
				// $id=$this->input->post('id');
				// $this->My_newmodel->update_record($name,$city,$password,$mobile,$email,$id);
			}
			// redirect("newdemo/displaydata");
		
	
	public function creative_demo(){
		if($this->input->post('btn')){//check value is set or not
			//receiving value by view
			$this->form_validation->set_rules('name','Name','required');
		$this->form_validation->set_rules('email','Email','required');
		$this->form_validation->set_rules('mobile','Mobile','required');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('city','City','required');
				$name=$this->input->post('name');
				$email=$this->input->post('email');
				$password=$this->input->post('password');
				$mobile=$this->input->post('mobile');
				$city=$this->input->post('city');
				$id=$this->input->post('id');
				$this->My_newmodel->update_record($name,$city,$password,$mobile,$email,$id);
				//send value to model
				redirect("newdemo/displaydata");
			}
	}
	public function deletedata()
	{
		$id=$this->input->get('id');
		$this->My_newmodel->delete_newdata($id);
		//sending data to model
		redirect("newdemo/displaydata");
	}
}
?>