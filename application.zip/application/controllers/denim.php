<?php 
class denim extends CI_Controller
{	
	public function index()
	{
		// $a=5;
		// $b=1;
		// for($i=$a;$i>=1;$i--){ 
		// 	$b=$b*$i;
		// }		
		// $c['fac']=$b;		
		$this->load->view('new');
	}
	public function getdt()
	{	
		//$p=$_REQUEST['p'];
		//$r=$_REQUEST['r'];
		//$t=$_REQUEST['t'];
		$p=$this->input->post('p');
     	$r=$this->input->post('r');
     	$t=$this->input->post('t');
		$s['menu']=($p*$r*$t)/100;
		//$data['res']=$si;
	    //$data['p1']=$p;
	    //$data['r1']=$r;
	    //$data['t1']=$t;
		$this->load->view('new',$s);
	// 	$a=5;
	// 	$b=0;
	// 	for($i=2;$i<$a;$i++) { 
	// 		if($a%$i==0){
	// 			$b++;
	// 			break;
	// 		}
	// 	}
	// 	if($b>=1){
	// 		echo "not prime";
	// 	}			
	// 	else{
	// 		echo"prime";
	// 	}
		
	}

}
?>