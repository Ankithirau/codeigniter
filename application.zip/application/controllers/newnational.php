<?php
class newnational extends CI_Controller
{	
	function __construct()
{
    parent:: __construct();
    $this->load->Model('new_denim');
}

function index()
{
    $this->load->view('edit');
}

function user(){
    if (isset($_POST['btn']))
    {
        $data = array('name'=>$_POST['name'],
                    	'email'=>$_POST['class']);
         $this->new_denim->insert($data);
    	}
    }
}
?>