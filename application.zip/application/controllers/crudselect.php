<?php
class crudselect extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->model('crudmodel');
	}
	function index(){
		$this->load->view('selectview');
	}
	function crudinsert(){
		$this->form_validation->set_rules('name','name','required');
		$this->form_validation->set_rules('email','email','required');
		$this->form_validation->set_rules('city','city','required');
		if($this->form_validation->run()==False)
		{
   			$this->load->view('createview');

		}
		else{
		if ($this->input->post('btn')) {
		$data['name']=$this->input->post('name');
		$data['email']=$this->input->post('email');
		$data['city']=$this->input->post('city');
		$this->crudmodel->addinsert($data);
		if ($data) {
			redirect('crudselect/selectview');
		}
		else{
			echo"not inserted";
			}
		}
		}		
	}
	function addnew(){
		$this->load->view('createview');
	}
	function selectview(){
		$result['data']=$this->crudmodel->addselect();
		$this->load->view('selectview',$result);
	}
	function deldt(){
		$id=$_REQUEST['id'];
		$this->crudmodel->delgt($id);
		redirect('crudselect/selectview');
	}
	function updt(){
		$id=$_REQUEST['id'];
		$result['gym']=$this->crudmodel->upgt($id);
		// $result['data']=$this->crudmodel->upgt();
		$this->load->view('upview',$result);
	}
	function upinsert(){
		if ($this->input->post('btn')) {
			$id=$this->input->post('id');
			$name=$this->input->post('name');
			$email=$this->input->post('email');
			$city=$this->input->post('city');
		// $data['id']=$this->input->post('id');
		// $data['name']=$this->input->post('name');
		// $data['email']=$this->input->post('email');
		// $data['city']=$this->input->post('city');
		$this->crudmodel->minsert($id,$name,$email,$city);
	}
		redirect('crudselect/selectview');
	
	}

}
?>