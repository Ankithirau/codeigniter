<!DOCTYPE html>
<html>
<head>
	<title>factorial number</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body class="<?php 
			//foreach ( as $key ) {
				echo @$blue;
				echo @$red;
				echo @$green;
			//} ?>">
<!-- <center> -->
	<!-- <div class="container-fluid w-25 mt-5">
	<form method="post" action="">
		<label for="exampleFormControlInput1" class="form-label">
		Check factorial of a number</label>
		<input type="text" class="form-control mb-3" id="exampleFormControlInput1" placeholder="Enter Number" name="n">
		<input type="submit" class="btn btn-primary" id="exampleFormControlInput1" name="btn">
	</form>
	</div> -->
	
	<center>
		<form method="post" action="<?= base_url('colornew/getdt');?>">
	<button class="btn btn-primary" name="blue" value="bg-primary">Blue</button>
	<button class="btn btn-danger" name="red" value="bg-danger">Red</button>
	<button class="btn btn-success" name="green" value="bg-success">Green</button>
	</form>
	</center>
<!-- </center> -->
</body>
</html>

	<!-- 	// foreach ($getdt as $key => $value) {
			// echo $value->name."&nbsp&nbsp".$value->mob."&nbsp&nbsp".$value->addres ;
			// echo "<br>";
			// echo ;
			// echo "<br>";
			// echo $value->addres;
			// echo "<br>";
		// }
 -->
	 