<!DOCTYPE html>
<html>
<head>
	<title>Add User</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>

<div class="container-fluid w-50 bg-light mt-5">
	<form method="post" action="<?= base_url('crudselect/upinsert');?>" >
		<?php
		foreach (@$gym as $key => $value) {
			?>
	<input type="text" name="name" class="form-control mb-2" placeholder="Enter Name Here" value="<?php echo $value->name ;?>">
	<input type="email" name="email" class="form-control mb-2" placeholder="Enter Email Here" value="<?php echo $value->email ;?>">
	<input type="hidden" name="id" class="form-control mb-2" value="<?php echo $value->id;?>">
	<input type="city" name="city" class="form-control mb-2"
	placeholder="Enter City Here" value="<?php echo $value->city ;?>">
	<input type="submit" name="btn" class="btn btn-primary">
	<?php
	}
	?>
	</form>
</div>
</body>
</html>

<?php
//echo"<pre>";
//print_r(@$gym);
?>