<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
	<!-- showing result in this page -->
	<center>
<a href="<?= site_url('newdemo/new_update_skill');?>" class="btn btn-primary">Add new</a>
</center>	
<table class="mt-3 table table-hover table-striped text-center">
	<thead class="text-capitalize">
		<tr>
			<th>S no.</th>
			<th>Name</th>
			<th>Email</th>
			<th>Password</th>
			<th>Mobile</th>
			<th>City</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>

<?php 
$s=0;
foreach(@$menu as $key => $value) {
	$s++;
	?>
	<tr>
		<td><?php echo $s;?></td>
		<td><?php echo $value->name;?></td>
		<td><?php echo $value->email;?></td>
		<td><?php echo $value->password;?></td>
		<td><?php echo $value->mobile;?></td>
		<td><?php echo $value->city;?></td>
		<td><a href="updatedata?id=<?php echo $value->id;?>" class="btn btn-success"
			>Update</a>
		<a href="deletedata?id=<?php echo $value->id;?>" class="btn btn-danger"
			>Delete</a></td>
	</tr>
<?php
}
// print_r(@$win);
?>
</tbody>
</table>
</body>
</html>