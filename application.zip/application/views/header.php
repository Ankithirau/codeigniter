<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assest/style.css');?>">
</head>
<body>
<header>
	<ul>
		<li><a href="<?= base_url('Newweb/index')?>">Home</a></li>
		<li><a href="<?= base_url('Newweb/Aboutus')?>">About Us</a></li>
		<li><a href="<?= base_url('Newweb/services')?>">Services</a></li>
		<li><a href="<?= base_url('Newweb/Contactus')?>">Contact Us</a></li>
	</ul>
	<!-- <a href=""></a>
	<p></p>
	<div class=""></div> -->
</header>