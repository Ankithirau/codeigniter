<!DOCTYPE html>
<html>
<head>
	<title>Prime Number</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body class="bg-light">
<center>
	<div class="container-fluid w-25 mt-5">
	<form method="post" action="<?= site_url('prime/usedt');?>">
		<label for="exampleFormControlInput1" class="form-label">
		Check Number is prime or not</label>
		<input type="text" class="form-control mb-3" id="exampleFormControlInput1" placeholder="Enter Number" name="n">
		<input type="submit" class="btn btn-primary" id="exampleFormControlInput1" name="btn">
	</form>
	</div>
</center>
</body>
</html>