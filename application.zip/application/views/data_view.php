<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
<table>
	<thead>
		<tr>
		<th>Name</th>
		<th>Email</th>
		<th>Password</th>
		<th>Mobile Number</th>
		<th>Current City</th>
		</tr>
	</thead>
	<?php
		foreach ($record as $key => $value) {
		?>
		<tbody>
		<tr>
			 <td><?php echo $value; ?></td>
			 <td><?php echo $value; ?></td> 
			 <td><?php echo $value; ?></td> 
			 <td><?php echo $value; ?></td> 
			 <td><?php echo $value; ?></td> 
		</tr>
		</tbody>
	<?php
	}
	?>
	
</table>
</body>
</html>