<!DOCTYPE html>
<html>
	<head>
		<title>Registration</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
	</head>
	<body class="bg-light">
		<center>
		<div class="container w-25 mt-5">
		 <form method="post" action="<?= site_url('denim/getdt');?>">
				<div class="mb-3">
					<label for="exampleFormControlInput1" class="form-label">
					Principal</label>
					<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter principal here" name="p">
				</div>
				<div class="mb-3">
					<label for="exampleFormControlInput1" class="form-label">Rate</label>
					<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter rate here" name="r">
				</div>
				<div class="mb-3">
					<label for="exampleFormControlInput1" class="form-label">Time</label>
					<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter time here" name="t">
				</div>
				<input type="submit" name="btn" class="btn btn-primary">
			</form>
		</div>
		<h3 class='mt-4 text-success'>
		<?php
		 echo @$menu;
		 ?>
         </h3>
		</center>
			
	</body>
</html>