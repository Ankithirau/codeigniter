<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
	</head>
	<body>
		<!-- fetching data from database -->
		<?php
		foreach (@$win as $key=> $value) {
		?>
		<div class="container w-50 mt-3">
			<form method="post" action="<?php echo base_url('newdemo/creative_demo');?>">
				<input class="form-control" type="text" name="name" value="<?php echo $value->name; ?>" ><br>
				<input type="email" class="form-control" name="email" value="<?php echo $value->email; ?>"><br>
				<input type="password" class="form-control" name="password" value="<?php echo $value->password; ?>"><br>
				<input type="text" name="mobile" class="form-control" value="<?php echo $value->mobile; ?>"><br>
				<input type="text" name="city" class="form-control" value="<?php echo $value->city;?>"><br>
				<input type="hidden" name="id" value="<?php echo $value->id;?>"><br>
				<center>
				<input type="submit" name="btn" class="btn btn-success">
				</center>
				<?php
				}
				?>
			</form>
		</div>
	</body>
</html>