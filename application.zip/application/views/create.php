<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
	</head>
	<body class="bg-light">
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid">
				<a class="navbar-brand" href="#">CRUD Application in Codeigniter</a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
			</div>
		</nav>
		<div class="container mt-3" style="width: 40%;">
			<form method="post" action="<?php echo base_url().'user/create';?>">
				<div class="mb-1">
					<label for="exampleFormControlInput1" class="form-label">Name</label>
					<input type="text" class="form-control" placeholder="Enter your full name" name="name" value="<?php set_value('name'); ?>">
					<?php echo form_error('name');?>
				</div>
				<div class="mb-1">
					<label for="exampleFormControlInput1" class="form-label">Email ID</label>
					<input type="email" class="form-control" placeholder="Enter your email" name="email" value="<?php set_value('email'); ?>">
					<?php echo form_error('email');?>
				</div>
				<div class="mb-1">
					<label for="exampleFormControlInput1" class="form-label">Create Password</label>
					<input type="Password" class="form-control" placeholder="Enter your password" name="password" value="<?php set_value('password'); ?>">
					<?php echo form_error('password');?>
				</div>
				<div class="mb-1">
					<label for="exampleFormControlInput1" class="form-label">Mobile Number</label>
					<input type="text" class="form-control" placeholder="Enter your mobile number" name="mobile" value="<?php set_value('mobile'); ?>">
					<?php echo form_error('mobile');?>
				</div>
				<div class="mb-1">
					<label for="exampleFormControlInput1" class="form-label">Current City</label>
					<input type="text" class="form-control" placeholder="Enter your city" name="city" value="<?php set_value('city');?>">
					<?php echo form_error('city');?>
				</div>
				<center>
				<div class="mt-3">
					<input type="submit" class="btn btn-primary" placeholder="Enter your full name" name="btn">
				</div>
				<?php echo word_limiter($string,1);
				?>
				</center>
			</form>
		</div>
	</body>
</html>