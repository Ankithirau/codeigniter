<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="post" action="<?= base_url('myprac/newdt')?>">
<input type="text" name="name">
<input type="submit" name="btn">
</form>
</body>
</html>