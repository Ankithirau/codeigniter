<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
		foreach ($getdt as $key => $value) {
			echo "<pre>";
			echo "<hr>";
			echo $value->name;
			echo "</pre>";
		}
		?>
<?php //echo "$fac <br>"; ?>
<?php //echo $pre;?>
</body>
</html>