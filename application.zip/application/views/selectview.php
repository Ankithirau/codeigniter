<!DOCTYPE html>
<html>
<head>
	<title>Deshboard</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>	
	<a href="<?= base_url('crudselect/addnew')?>" class="btn btn-primary mt-2" style="float: right;">+Add New</a>
<div class="container-fluid">
	<table class="table table-hover table-striped text-center">
		<thead>
			<tr>
				<th>Sno.</th>
				<th>Name</th>
				<th>Email</th>
				<th>City</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php
			// echo"<pre>";
			// print_r(@$data);
			$s=0;
			foreach (@$data as $key => $value){
				$s++;
			?>
			<tr>
				<td><?php echo $s;?></td>
				<td><?php echo $value->name;?></td>
				<td><?php echo $value->email;?></td>
				<td><?php echo $value->city;?></td>
				<td><a href="updt?id=<?php echo $value->id;?>" class="btn btn-success">Update</a>
					<a href="deldt?id=<?php echo $value->id;?>" class="btn btn-danger">Delete</a></td>
			</tr>
		<?php }?>		
		</tbody>
	</table>
</div>
</body>
</html>