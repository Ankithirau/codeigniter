<!DOCTYPE html>
<html>
<head>
	<title><?= $Home;?></title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-primary">
			<div class="container-fluid">
				<a class="navbar-brand text-white" href="<?= base_url('eng/index');?>">Welcome in Codeigniter</a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse " id="navbarNavAltMarkup">
				<div class="navbar-nav">
						<a class="nav-link active text-white" href="<?= base_url('home');?>">Home</a>
						<a class="nav-link text-white" href="<?= base_url('about');?>">Abouts Us</a>
						<a href="<?= base_url('eng/index');?>" class="nav-link text-white">back</a>
					</div>
				</div>
			</div>
		</nav>
		<h1 class="text-primary h4">Welcome in Home page</h1>
</body>
</html>