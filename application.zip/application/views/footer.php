<footer>
	<center>
	&copy; Desgin by Ankit
	</center>
</footer>
</body>
</html>