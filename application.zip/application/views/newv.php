<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
	</head>
	<body class="bg-light">
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
			<div class="container-fluid">
				<a class="navbar-brand" href="#">New From</a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
					<div class="navbar-nav">
						<a class="nav-link active" aria-current="page" href="#">Home</a>
						<a class="nav-link" href="#">About</a>
						<a class="nav-link" href="#">Service</a>
					</div>
				</div>
			</div>
		</nav>
		<div class="container mt-3" style="width: 40%;">
			<form method="post" action="<?=base_url();?>Newmargin/newdt">
				<div class="mb-1">
					<label for="exampleFormControlInput1" class="form-label">Name</label>
					<input type="text" class="form-control" placeholder="Enter your full name" name="nam">
				</div>
				<div class="mb-1">
					<label for="exampleFormControlInput1" class="form-label">Email ID</label>
					<input type="email" class="form-control" placeholder="Enter your full name" name="em">
				</div>
				<div class="mb-1">
					<label for="exampleFormControlInput1" class="form-label">Create Password</label>
					<input type="Password" class="form-control" placeholder="Enter your full name" name="pass">
				</div>
				<div class="mb-1">
					<label for="exampleFormControlInput1" class="form-label">Mobile Number</label>
					<input type="text" class="form-control" placeholder="Enter your full name" name="mob">
				</div>
				<div class="mb-1">
					<label for="exampleFormControlInput1" class="form-label">Current City</label>
					<input type="text" class="form-control" placeholder="Enter your full name" name="city">
				</div>
				<center>
				<div class="mt-3">
					<input type="submit" class="btn btn-primary" placeholder="Enter your full name" name="btn">
				</div>
				</center>
			</form>
		</div>
	</body>
</html>