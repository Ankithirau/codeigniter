<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
<!-- update page -->
<div class="container mt-5">
  <div class="row w-50">
  <div class="col">
<form action="<?= base_url('newdemo/res');?>" method="post">
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">Name</span>
  <input type="text" class="form-control" placeholder="Enter name" aria-label="Username" aria-describedby="basic-addon1" name="name">
</div>
<?php echo form_error('name');?>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">Email</span>
  <input type="email" class="form-control" placeholder="Enter email" aria-label="Username" aria-describedby="basic-addon1" name="email">
</div>
<?php echo form_error('email');?>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">Password</span>
  <input type="password" class="form-control" placeholder="Enter Password" aria-label="Username" aria-describedby="basic-addon1" name="password">
</div>
<?php echo form_error('password');?>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">Mob. no.</span>
  <input type="text" class="form-control" placeholder="Enter Mobile" aria-label="Username" aria-describedby="basic-addon1"  name="mobile">
</div>
<?php echo form_error('mobile');?>
<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">City</span>
  <input type="text" class="form-control" placeholder="Enter City" aria-label="Username" aria-describedby="basic-addon1" name="city">
</div>
<?php echo form_error('city');?>
<center>
<input type="submit" name="btn" class="btn btn-primary">
</center>
</form>
</div>
</div>
</div>
</body>
</html>
