<form method="post" action="<?php echo base_url().'newnational/user';?>">
<input type="text" name="name"/>
<input type="text" name="class"/>
<input type="submit" name="btn">
</form>