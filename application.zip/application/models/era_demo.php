<?php
class era_demo extends CI_model
{
	function unique_demo($data){
		$this->db->insert('demo',$data);
	}
}

?>