<?php
class My_Model extends CI_Model
{	
	
	public function home($data){
		// $query="insert into demo value('','$name','$email','$password','$mobile','$city')";
		// $this->db->query($query);
		$this->db->insert('demo',$data);	
	}
	
}
?>