<?php

class new_denim extends CI_model
{
	function insert($data){
    $this->db->insert('demo',$data);
    return true;
	}
}
?>