<?php
class loginmodel extends CI_Model
{
	
	function nlogin($name,$pass){
		$result=$this->db->get_where('demo',array('email'=>$name,'password'=>$pass));
		return $result->num_rows();
	}
}
?>