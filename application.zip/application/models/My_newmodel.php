<?php
class My_newmodel extends CI_model
{
	public function msg($data)
	{
		$this->db->insert('demo',$data);//insert data to database
	}
	public function fetch_data(){
		$query=$this->db->query("select * from demo");
		//select data from database
		return $query->result();//return value in result();
	}
	public function update_newdata($id){
		$deo=$this->db->query("select * from demo where id='".$id."'");
		//select data by id
		return $deo->result();
	}
	public function update_record($name,$city,$password,$mobile,$email,$id){
		// $this->db->where('id',$id);
		// $this->db->update('dem',$data);
		$this->db->query("update demo set name='$name',email='$email',password='$password',city='$city',mobile='$mobile' where id='".$id."'");
		//update query
	}
	public function delete_newdata($id){
		$this->db->query("delete from demo where id='".$id."'");
		//delete data
	}
}

?>