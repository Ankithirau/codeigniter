<?php
class User_model extends CI_Model
{
	function create ($dtarray){
	$this->db->insert("demo",$dtarray);//insert into demo(name,email,mobile,password,city) value($dtarray)
	}
	
}

?>