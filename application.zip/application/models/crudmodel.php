<?php
class crudmodel extends CI_Model
{
	function __construct(){
		parent::__construct();
		$this->load->model('crudmodel');
	}
	function addinsert($data){
		$res=$this->db->insert('demo',$data);
		return $res;
	}
	function addselect(){
		$sql=$this->db->query("select * from demo");
		return $sql->result();
	}
	function delgt($id){
		$this->db->where('id',$id);
		$res=$this->db->delete('demo');
		return $res;
	}
	function upgt($id){
		// $this->db->where($id);
		$sel=$this->db->query("select * from demo where id='".$id."'");
		return $sel->result();
	}
	function minsert($id,$name,$email,$city){
		// $this->db->set('name','email','city',true);
		// $this->db->where('id',$id);
		// $this->db->update('demo',$data);
		$n=$this->db->query("update demo set name='$name',email='$email',city='$city' where id='".$id."'");
		return $n;
	}	
}

?>