<?php
 function msg(){
	echo "<marquee><h1 style='color:red;'>CI batch will be finished earlier hence prepare project</marquee></h1>";
}
?>